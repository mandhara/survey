package com.cg.survey.service;

import com.cg.survey.bean.User;
import com.cg.survey.exception.SurveyProblemException;


public interface LoginService {
	
public int userLoginService(User loginUser);


}
