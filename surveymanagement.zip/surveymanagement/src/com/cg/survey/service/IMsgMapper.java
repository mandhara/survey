package com.cg.survey.service;

public interface IMsgMapper {
 public static final String ID_ERROR="Enter valid ID(numbers)";
}
