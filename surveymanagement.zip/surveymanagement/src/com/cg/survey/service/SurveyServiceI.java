package com.cg.survey.service;

import java.util.ArrayList;

import com.cg.survey.bean.DistributedSurveys;
import com.cg.survey.bean.DistributedSurveys1;
import com.cg.survey.bean.DistributedSurveys2;
import com.cg.survey.bean.SurveyDistribution;
import com.cg.survey.bean.SurveyMaster;
import com.cg.survey.bean.SurveyQuestionDetails;
import com.cg.survey.bean.SurveyQuestionOptions;
import com.cg.survey.bean.SurveyRespondentsAnswers;
import com.cg.survey.exception.SurveyProblemException;

public interface SurveyServiceI {
	
        public int createSurvey(SurveyMaster SurveyDetails ) throws SurveyProblemException;
        public int createQuestion(SurveyQuestionDetails QuestionDetails,SurveyMaster SurveyDetails) throws SurveyProblemException;
        public int createOptions(SurveyQuestionOptions OptionDetails,SurveyQuestionDetails QuestionDetails) throws SurveyProblemException;
        
        public int editSurvey(SurveyQuestionDetails QuestionDetails, SurveyMaster SurveyDetails ) throws SurveyProblemException;
        
        public  ArrayList<SurveyMaster> viewSurveys() throws SurveyProblemException ;
        public  ArrayList<SurveyQuestionOptions> addOptions() throws SurveyProblemException ;
        
        public int distributeSurvey(SurveyDistribution DistributionDetails,SurveyMaster SurveyDetails1) throws SurveyProblemException;
	
        public abstract ArrayList<DistributedSurveys> RespondSurveys() throws SurveyProblemException ;
        
        public abstract ArrayList<DistributedSurveys1> RespondSurveys1(int surveyId) throws SurveyProblemException ;
        
   
       
        public abstract boolean isValidId(String SurveyId) throws SurveyProblemException;
        
}
        
        
        
       
        



