package com.cg.survey.service;

import java.util.ArrayList;





import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.survey.bean.DistributedSurveys;
import com.cg.survey.bean.DistributedSurveys1;
import com.cg.survey.bean.DistributedSurveys2;
import com.cg.survey.bean.SurveyDistribution;
import com.cg.survey.bean.SurveyMaster;
import com.cg.survey.bean.SurveyQuestionDetails;
import com.cg.survey.bean.SurveyQuestionOptions;
import com.cg.survey.bean.SurveyRespondentsAnswers;
import com.cg.survey.dao.ISurveyDao;
import com.cg.survey.dao.SurveyDaoImp;
import com.cg.survey.exception.SurveyProblemException;

public  class SurveyServiceImplementation implements SurveyServiceI {
    ISurveyDao SurveyDao=null;

	@Override
	public  int createSurvey(SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		
		SurveyDao=new SurveyDaoImp();
	return SurveyDao.createSurvey(SurveyDetails);
	}

	@Override
	public int createQuestion(SurveyQuestionDetails QuestionDetails,SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
	return SurveyDao.createQuestion(QuestionDetails,SurveyDetails);
	}

	@Override
	public int createOptions(SurveyQuestionOptions OptionDetails,SurveyQuestionDetails QuestionDetails)
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.createOptions(OptionDetails,QuestionDetails);
	

	}

	@Override
	public int editSurvey(SurveyQuestionDetails QuestionDetails,SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.editSurvey(QuestionDetails,SurveyDetails);
	}

	@Override
	public ArrayList<SurveyMaster> viewSurveys() throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.viewSurveys();
		
	}

	@Override
	public int distributeSurvey(SurveyDistribution DistributionDetails,
			SurveyMaster SurveyDetails1) throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.distributeSurvey(DistributionDetails,SurveyDetails1);
		}

	@Override
	public ArrayList<SurveyQuestionOptions> addOptions()
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.addOptions();
		
	}

	@Override
	public ArrayList<DistributedSurveys> RespondSurveys()
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.RespondSurveys();
		
	}

	@Override
	public ArrayList<DistributedSurveys1> RespondSurveys1(int surveyId)
			throws SurveyProblemException {
		SurveyDao=new SurveyDaoImp();
		return SurveyDao.RespondSurveys1(surveyId);
	}

	@Override
	public boolean isValidId(String SurveyId) throws SurveyProblemException {
		Pattern pattern = Pattern.compile("[0-9]{1,3}-[0-9]{3}\\-[0-9]{7}");
		Matcher matcher = pattern.matcher(SurveyId);
		return matcher.matches();
	}

	


	}

	










	
	


