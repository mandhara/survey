package com.cg.survey.service;

import com.cg.survey.bean.User;
import com.cg.survey.dao.LoginDao;
import com.cg.survey.dao.LoginDaoImp;
import com.cg.survey.exception.SurveyProblemException;

public class LoginServiceImp implements LoginService {
	LoginDaoImp dao = null;

	@Override
	public int userLoginService(User loginUser) {
		// Creating Instance Of DAO Implementation Class
		dao = new LoginDaoImp();
		// LoginUserToDatabase method and return User Type
		return dao.loginUserToDatabase(loginUser);
	}
	
}
