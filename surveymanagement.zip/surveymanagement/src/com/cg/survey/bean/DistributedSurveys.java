package com.cg.survey.bean;

public class DistributedSurveys {
	private int SurveyId;
	private String SurveyTitle;
	private int DistributionId;
	private String DistributedDate;
	@Override
	public String toString() {
		return "DistributedSurveys [SurveyId=" + SurveyId + ", SurveyTitle="
				+ SurveyTitle + ", DistributionId=" + DistributionId
				+ ", DistributedDate=" + DistributedDate + "]";
	}
	public DistributedSurveys() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public DistributedSurveys(int surveyId, String surveyTitle,
			int distributionId, String distributedDate) {
		super();
		SurveyId = surveyId;
		SurveyTitle = surveyTitle;
		DistributionId = distributionId;
		DistributedDate = distributedDate;
		
	}
	public int getSurveyId() {
		return SurveyId;
	}
	public void setSurveyId(int surveyId) {
		SurveyId = surveyId;
	}
	public String getSurveyTitle() {
		return SurveyTitle;
	}
	public void setSurveyTitle(String surveyTitle) {
		SurveyTitle = surveyTitle;
	}
	public int getDistributionId() {
		return DistributionId;
	}
	public void setDistributionId(int distributionId) {
		DistributionId = distributionId;
	}
	public String getDistributedDate() {
		return DistributedDate;
	}
	public void setDistributedDate(String distributedDate) {
		DistributedDate = distributedDate;
	}
}
