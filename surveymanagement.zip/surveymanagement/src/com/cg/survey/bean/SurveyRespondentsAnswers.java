package com.cg.survey.bean;

public class SurveyRespondentsAnswers {
	private int UserId;
	private int respondentUserId;
	private int DistributionId;
	private int QuestionId;
	private int OptionId;
	private String AnswerText;

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public SurveyRespondentsAnswers(int userId, int respondentUserId,
			int distributionId, int questionId, int optionId, String answerText) {
		super();
		UserId = userId;
		this.respondentUserId = respondentUserId;
		DistributionId = distributionId;
		QuestionId = questionId;
		OptionId = optionId;
		AnswerText = answerText;
	}

	public int getDistributionId() {
		return DistributionId;
	}

	public void setDistributionId(int distributionId) {
		DistributionId = distributionId;
	}

	public int getQuestionId() {
		return QuestionId;
	}

	public void setQuestionId(int questionId) {
		QuestionId = questionId;
	}

	public int getOptionId() {
		return OptionId;
	}

	public void setOptionId(int optionId) {
		OptionId = optionId;
	}

	public String getAnswerText() {
		return AnswerText;
	}

	public void setAnswerText(String answerText) {
		AnswerText = answerText;
	}

	public SurveyRespondentsAnswers() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SurveyRespondentsAnswers [UserId=" + UserId
				+ ", DistributionId=" + DistributionId + ", QuestionId="
				+ QuestionId + ", OptionId=" + OptionId + ", AnswerText="
				+ AnswerText + "]";
	}

}
