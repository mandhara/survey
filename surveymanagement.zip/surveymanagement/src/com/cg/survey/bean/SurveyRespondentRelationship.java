package com.cg.survey.bean;

public class SurveyRespondentRelationship {
	private int DistributionId;
	private String UserId;
	private String ResponseStatus;

	public int getDistributionId() {
		return DistributionId;
	}

	public void setDistributionId(int distributionId) {
		DistributionId = distributionId;
	}

	public String getUserId() {
		return UserId;
	}

	public SurveyRespondentRelationship(int distributionId, String userId,
			String responseStatus) {
		super();
		DistributionId = distributionId;
		UserId = userId;
		ResponseStatus = responseStatus;
	}

	public void setUserId(String userId) {
		UserId = userId;
	}

	public String getResponseStatus() {
		return ResponseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		ResponseStatus = responseStatus;
	}

	public SurveyRespondentRelationship() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SurveyRespondentRelationship [DistributionId=" + DistributionId
				+ ", UserId=" + UserId + ", ResponseStatus=" + ResponseStatus
				+ "]";
	}

}
