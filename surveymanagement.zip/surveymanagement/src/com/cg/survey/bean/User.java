package com.cg.survey.bean;

public class User {

	private int UserId;
	private String UserPassword;
	private String FirstName;
	private String LastName;
	private String UserType;

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getUserType() {
		return UserType;
	}

	public void setUserType(String userType) {
		UserType = userType;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SurveyBean [UserId=" + UserId + ", UserPassword="
				+ UserPassword + ", FirstName=" + FirstName + ", LastName="
				+ LastName + ", UserType=" + UserType + "]";
	}

}
