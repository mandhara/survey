package com.cg.survey.bean;

import java.time.LocalDate;

public class SurveyDistribution {
	private int DistributionId;
	private int SurveyId;
	private String SurveyTitle;
	private String DistributedDate;
    
	@Override
	public String toString() {
		return "SurveyDistribution [DistributionId=" + DistributionId
				+ ", SurveyId=" + SurveyId + ", SurveyTitle=" + SurveyTitle
				+ ", DistributedDate=" + DistributedDate + "]";
	}
	public SurveyDistribution(int distributionId, int surveyId,
			String surveyTitle, String distributedDate) {
		super();
		DistributionId = distributionId;
		SurveyId = surveyId;
		SurveyTitle = surveyTitle;
		DistributedDate = distributedDate;
	}
	public SurveyDistribution() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDistributionId() {
		return DistributionId;
	}
	public void setDistributionId(int distributionId) {
		DistributionId = distributionId;
	}
	public int getSurveyId() {
		return SurveyId;
	}
	public void setSurveyId(int surveyId) {
		SurveyId = surveyId;
	}
	public String getSurveyTitle() {
		return SurveyTitle;
	}
	public void setSurveyTitle(String surveyTitle) {
		SurveyTitle = surveyTitle;
	}
	public String getDistributedDate() {
		return DistributedDate;
	}
	public void setDistributedDate(String distributedDate) {
		DistributedDate = distributedDate;
	}
	
}