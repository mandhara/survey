package com.cg.survey.bean;

public class SurveyQuestionDetails {
	private int QuestionId;
	private int SurveyId;
	public SurveyQuestionDetails(int questionId, int surveyId,
			String questionText, int questionType) {
		super();
		QuestionId = questionId;
		SurveyId = surveyId;
		QuestionText = questionText;
		QuestionType = questionType;
	}

	private String QuestionText;
	private int QuestionType;

	public int getQuestionId() {
		return QuestionId;
	}

	public void setQuestionId(int questionId) {
		QuestionId = questionId;
	}

	public int getSurveyId() {
		return SurveyId;
	}

	public void setSurveyId(int surveyId) {
		SurveyId = surveyId;
	}

	public String getQuestionText() {
		return QuestionText;
	}

	public void setQuestionText(String questionText) {
		QuestionText = questionText;
	}

	public int getQuestionType() {
		return QuestionType;
	}

	public void setQuestionType(int questionType) {
		QuestionType = questionType;
	}

	public SurveyQuestionDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SurveyQuestionDetails [QuestionId=" + QuestionId
				+ ", SurveyId=" + SurveyId + ", QuestionText=" + QuestionText
				+ ", QuestionType=" + QuestionType + "]";
	}

}
