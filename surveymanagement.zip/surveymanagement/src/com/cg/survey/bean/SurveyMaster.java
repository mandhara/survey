package com.cg.survey.bean;

import java.util.ArrayList;

import com.cg.survey.dao.SurveyDaoImp;

public class SurveyMaster {
	private int SurveyId;
	private String SurveyTitle;
	private String SurveyDescription;
	private int UserId;

	public int getSurveyId() {
		return SurveyId;
	}

	public void setSurveyId(int surveyId) {
		SurveyId = surveyId;
	}

	public String getSurveyTitle() {
		return SurveyTitle;
	}

	public void setSurveyTitle(String surveyTitle) {
		SurveyTitle = surveyTitle;
	}

	public String getSurveyDescription() {
		return SurveyDescription;
	}

	public void setSurveyDescription(String surveyDescription) {
		SurveyDescription = surveyDescription;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public SurveyMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SurveyMaster(int surveyId, String surveyTitle,
			String surveyDescription, int userId) {
		super();
		SurveyId = surveyId;
		SurveyTitle = surveyTitle;
		SurveyDescription = surveyDescription;
		UserId = userId;
	}

	@Override
	public String toString() {
		return "SurveyMaster [SurveyId=" + SurveyId + ", SurveyTitle="
				+ SurveyTitle + ", SurveyDescription=" + SurveyDescription
				+ ", UserId=" + UserId + "]";
	}
	
	/*   public ArrayList<SurveyMaster> get() {
	        ArrayList<SurveyMaster>  s = SurveyDaoImp.getCreateSurvey();
	        ArrayList<SelectItem> items = new ArrayList<SelectItem>();

	        for ( Topic t : lst)
	            items.add( new SelectItem( t.getId(), t.getTitle()));

	        return items;
	    }
*/
}
