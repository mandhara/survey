package com.cg.survey.bean;

public class DistributedSurveys2 {
	private int SurveyId;
	private String SurveyTitle;
	private String SurveyDescription;
	private int QuestionId;
	private String QuestionText;
	private int OptionId;
	private int OptionId1;
	private String OptionDescription1;
	private int OptionId2;
	private String OptionDescription2;
	private int OptionId3;
	private String OptionDescription3;
	private int OptionId4;
	private String OptionDescription4;
	public int getSurveyId() {
		return SurveyId;
	}
	public void setSurveyId(int surveyId) {
		SurveyId = surveyId;
	}
	public String getSurveyTitle() {
		return SurveyTitle;
	}
	public void setSurveyTitle(String surveyTitle) {
		SurveyTitle = surveyTitle;
	}
	public String getSurveyDescription() {
		return SurveyDescription;
	}
	public void setSurveyDescription(String surveyDescription) {
		SurveyDescription = surveyDescription;
	}
	public int getQuestionId() {
		return QuestionId;
	}
	public void setQuestionId(int questionId) {
		QuestionId = questionId;
	}
	public String getQuestionText() {
		return QuestionText;
	}
	public void setQuestionText(String questionText) {
		QuestionText = questionText;
	}
	public int getOptionId() {
		return OptionId;
	}
	public void setOptionId(int optionId) {
		OptionId = optionId;
	}
	public int getOptionId1() {
		return OptionId1;
	}
	public void setOptionId1(int optionId1) {
		OptionId1 = optionId1;
	}
	public String getOptionDescription1() {
		return OptionDescription1;
	}
	public void setOptionDescription1(String optionDescription1) {
		OptionDescription1 = optionDescription1;
	}
	public int getOptionId2() {
		return OptionId2;
	}
	public void setOptionId2(int optionId2) {
		OptionId2 = optionId2;
	}
	public String getOptionDescription2() {
		return OptionDescription2;
	}
	public void setOptionDescription2(String optionDescription2) {
		OptionDescription2 = optionDescription2;
	}
	public int getOptionId3() {
		return OptionId3;
	}
	public void setOptionId3(int optionId3) {
		OptionId3 = optionId3;
	}
	public String getOptionDescription3() {
		return OptionDescription3;
	}
	public void setOptionDescription3(String optionDescription3) {
		OptionDescription3 = optionDescription3;
	}
	public int getOptionId4() {
		return OptionId4;
	}
	public void setOptionId4(int optionId4) {
		OptionId4 = optionId4;
	}
	public String getOptionDescription4() {
		return OptionDescription4;
	}
	public void setOptionDescription4(String optionDescription4) {
		OptionDescription4 = optionDescription4;
	}
	public DistributedSurveys2(int surveyId, String surveyTitle,
			String surveyDescription, int questionId, String questionText,
			int optionId, int optionId1, String optionDescription1,
			int optionId2, String optionDescription2, int optionId3,
			String optionDescription3, int optionId4, String optionDescription4) {
		super();
		SurveyId = surveyId;
		SurveyTitle = surveyTitle;
		SurveyDescription = surveyDescription;
		QuestionId = questionId;
		QuestionText = questionText;
		OptionId = optionId;
		OptionId1 = optionId1;
		OptionDescription1 = optionDescription1;
		OptionId2 = optionId2;
		OptionDescription2 = optionDescription2;
		OptionId3 = optionId3;
		OptionDescription3 = optionDescription3;
		OptionId4 = optionId4;
		OptionDescription4 = optionDescription4;
	}
	public DistributedSurveys2() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "DistributedSurveys1 [SurveyId=" + SurveyId + ", SurveyTitle="
				+ SurveyTitle + ", SurveyDescription=" + SurveyDescription
				+ ", QuestionId=" + QuestionId + ", QuestionText="
				+ QuestionText + ", OptionId=" + OptionId + ", OptionId1="
				+ OptionId1 + ", OptionDescription1=" + OptionDescription1
				+ ", OptionId2=" + OptionId2 + ", OptionDescription2="
				+ OptionDescription2 + ", OptionId3=" + OptionId3
				+ ", OptionDescription3=" + OptionDescription3 + ", OptionId4="
				+ OptionId4 + ", OptionDescription4=" + OptionDescription4
				+ "]";
	}
}


