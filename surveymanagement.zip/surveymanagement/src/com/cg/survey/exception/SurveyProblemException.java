package com.cg.survey.exception;

public class SurveyProblemException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public SurveyProblemException(String message) {
			super(message);
		}
		public SurveyProblemException(){
		
			
		
	}

}
