package com.cg.survey.dao;

import com.cg.survey.bean.User;
import com.cg.survey.exception.SurveyProblemException;

public interface LoginDao {

		public int loginUserToDatabase(User user);
	
}
