package com.cg.survey.dao;
import java.sql.*;
import java.util.ArrayList;

import com.cg.survey.bean.DistributedSurveys;
import com.cg.survey.bean.DistributedSurveys1;
import com.cg.survey.bean.DistributedSurveys2;
import com.cg.survey.bean.SurveyDistribution;
import com.cg.survey.bean.SurveyMaster;
import com.cg.survey.bean.SurveyQuestionDetails;
import com.cg.survey.bean.SurveyQuestionOptions;
import com.cg.survey.bean.SurveyRespondentsAnswers;
import com.cg.survey.bean.User;
import com.cg.survey.exception.SurveyProblemException;
import com.cg.survey.util.DAOUtil;


public class SurveyDaoImp implements ISurveyDao {
	private Connection conn = null;
	SurveyMaster surveyDetails = new SurveyMaster();
	SurveyMaster surveyDetails1 = new SurveyMaster();
	SurveyQuestionDetails QuestionDetails = new SurveyQuestionDetails();
	User loginUser = new User();
	@Override
	public int createSurvey(SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		int status = 0;
		try {
			conn = DAOUtil.establishConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.INSERT_INTO_SURVEY_MASTER);
			preparedStatement.setString(1, SurveyDetails.getSurveyTitle());
			preparedStatement.setString(2, SurveyDetails.getSurveyDescription());
			preparedStatement.setInt(3, SurveyDetails.getUserId());

			int storedStatus = preparedStatement.executeUpdate();
			
			
			if (storedStatus == 1) {

				status = 1;
			} else {
				status = 0;
			}
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(IQueryMapper.GET_SURVEY_SEQ_VALUE);
			while (rs.next()) {
				SurveyDetails.setSurveyId(rs.getInt(1));

			}
			
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;

	}
	
	@Override
	public int createQuestion(SurveyQuestionDetails QuestionDetails,SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		int status1 = 0;
		try {
			conn = DAOUtil.establishConnection();

		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.INSERT_INTO_SURVEY_QUESTIONS);
		
	      preparedStatement.setInt(1, SurveyDetails.getSurveyId());
			preparedStatement.setString(2, QuestionDetails.getQuestionText());
			preparedStatement.setInt(3, QuestionDetails.getQuestionType());
		System.out.println("g");
			int storedStatus1 = preparedStatement.executeUpdate();
				
			if (storedStatus1 == 1) {
				status1 = 1;
			} else {
				status1 = 0;
			}
			
			Statement stmt = conn.createStatement(); 
			ResultSet rs1 =stmt.executeQuery(IQueryMapper.GET_QUES_SEQ_VALUE); 
			 while(rs1.next())
			 {
				 QuestionDetails.setQuestionId(rs1.getInt(1));
			 
			 }
			
		

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status1;

	}


	@Override
	public int createOptions(SurveyQuestionOptions OptionDetails,SurveyQuestionDetails QuestionDetails)
			throws SurveyProblemException {
		int status2 = 0;
		try {
			conn = DAOUtil.establishConnection();
            PreparedStatement preparedStatement = conn.prepareStatement(IQueryMapper.INSERT_INTO_SURVEY_OPTIONS);
            preparedStatement.setInt(1, QuestionDetails.getQuestionId());
            preparedStatement.setInt(2, OptionDetails.getOptionId1());
			preparedStatement.setString(3, OptionDetails.getOptionDescription1());
			 preparedStatement.setInt(4, OptionDetails.getOptionId2());
			preparedStatement.setString(5, OptionDetails.getOptionDescription2());
			 preparedStatement.setInt(6 ,OptionDetails.getOptionId3());
			preparedStatement.setString(7, OptionDetails.getOptionDescription3());
			 preparedStatement.setInt(8, OptionDetails.getOptionId4());
	        preparedStatement.setString(9, OptionDetails.getOptionDescription4());
			
		
			
			int storedStatus2 = preparedStatement.executeUpdate();
			if (storedStatus2 == 1) {
				status2 = 1;
			} else {
				status2 = 0;
			}
			
		
			Statement stmt = conn.createStatement(); 
			ResultSet rs3 =stmt.executeQuery(IQueryMapper.GET_OPT_SEQ_VALUE); 
			 while(rs3.next())
			 {
				 OptionDetails.setOptionId(rs3.getInt(1));
			 
			 }
			
			

		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status2;

	}

	@Override
	public int editSurvey(SurveyQuestionDetails QuestionDetails,SurveyMaster SurveyDetails)
			throws SurveyProblemException {
		int status4 = 0;
		try {
			conn = DAOUtil.establishConnection();

		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.EDIT_ADD_QUESTION);
		
	      preparedStatement.setInt(1, SurveyDetails.getSurveyId());
			preparedStatement.setString(2, QuestionDetails.getQuestionText());
			preparedStatement.setInt(3, QuestionDetails.getQuestionType());
		
			int storedStatus1 = preparedStatement.executeUpdate();
				
			if (storedStatus1 == 1) {
				status4 = 1;
			} else {
				status4 = 0;
			}
			
			Statement stmt = conn.createStatement(); 
			ResultSet rs1 =stmt.executeQuery(IQueryMapper.GET_QUES_SEQ_VALUE); 
			 while(rs1.next())
			 {
				 QuestionDetails.setQuestionId(rs1.getInt(1));
			 
			 }
			
			 ResultSet rs2 =stmt.executeQuery(IQueryMapper.GET_SURVEY_SEQ_VALUE); 
						 while(rs2.next())
						 {
							 SurveyDetails.setSurveyId(rs2.getInt(2));
						 
						 }

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status4;
	
	}



	@Override
	public ArrayList<SurveyMaster> viewSurveys() throws SurveyProblemException {
	ArrayList<SurveyMaster> surveyList = new ArrayList<SurveyMaster>();
	try {
		conn = DAOUtil.establishConnection();

	PreparedStatement preparedStatement = conn
			.prepareStatement(IQueryMapper.VIEW_SURVEYS);
	ResultSet resultSet = preparedStatement.executeQuery();
	while(resultSet.next())
	{
		SurveyMaster surveyDetails1 = new SurveyMaster(resultSet.getInt(1),
			resultSet.getString(2),
			resultSet.getString(3),
			resultSet.getInt(4)
			);
		
		surveyList.add(surveyDetails1);
	}
	}
	 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	return surveyList;
	
	

	}

	@Override
	public int distributeSurvey(SurveyDistribution DistributionDetails,
			SurveyMaster SurveyDetails1) throws SurveyProblemException {
		
		int status = 0;
		try {
			conn = DAOUtil.establishConnection();
            PreparedStatement preparedStatement = conn.prepareStatement(IQueryMapper.INSERT_INTO_SURVEY_DISTRIBUTION);
         
			preparedStatement.setInt(1,SurveyDetails1.getSurveyId());
			preparedStatement.setString(2,DistributionDetails.getDistributedDate());
			
			int storedStatus = preparedStatement.executeUpdate();
			if (storedStatus == 1) {
				status = 1;
			} else {
				status = 0;
			}
			
		
			Statement stmt = conn.createStatement(); 
			ResultSet rs3 =stmt.executeQuery(IQueryMapper.GET_DIST_SEQ_VALUE); 
			 while(rs3.next())
			 {
				 DistributionDetails.setDistributionId(rs3.getInt(1));
			 
			 }
			
			
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return status;

	}

	@Override
	public ArrayList<SurveyQuestionOptions> addOptions()
			throws SurveyProblemException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DistributedSurveys> RespondSurveys()
			throws SurveyProblemException {
		ArrayList<DistributedSurveys> DistributedSurveyList = new ArrayList<DistributedSurveys>();
	
		try {
			conn = DAOUtil.establishConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.VIEW_DISTRIBUTED_SURVEYS);
			
		//	preparedStatement.setInt(1, surveyId);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {

				DistributedSurveys ds = new DistributedSurveys(rs.getInt(2),rs.getString(3),
						rs.getInt(1), rs.getString(4));
						

				DistributedSurveyList.add(ds);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return DistributedSurveyList;
	}

	
	@Override
	public ArrayList<DistributedSurveys1> RespondSurveys1(int surveyId)
			throws SurveyProblemException {
		ArrayList<DistributedSurveys1> DistributedSurveyList1 = new ArrayList<DistributedSurveys1>();
		
		try {
			conn = DAOUtil.establishConnection();

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.VIEW_DISTRIBUTED_SURVEYS1);
			
			preparedStatement.setInt(1,surveyId);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {

				DistributedSurveys1 ds1 = new DistributedSurveys1(rs.getInt(1),rs.getString(2),
						                                           rs.getString(3),rs.getInt(4),
						                                           rs.getString(5),rs.getInt(6),rs.getInt(7),
						                                           rs.getString(8),rs.getInt(9), rs.getString(10),rs.getInt(11),
						                                           rs.getString(12),rs.getInt(13),rs.getString(14));
						                                           

				DistributedSurveyList1.add(ds1);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return DistributedSurveyList1;
	}

	
	

}


		
	

			
		
		

