package com.cg.survey.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.survey.bean.User;
import com.cg.survey.exception.SurveyProblemException;
import com.cg.survey.util.DAOUtil;

public class LoginDaoImp implements LoginDao {
	private Connection conn = null;

	
	@Override
	public int loginUserToDatabase(User user) {
		// TODO Login User To Database
		// Return User Type To Service Method

		
		int userType = 0;

		try {

			conn = DAOUtil.establishConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.VALIDATE_USER_QUERY);

			preparedStatement.setInt(1, user.getUserId());
			preparedStatement.setString(2, user.getUserPassword());

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {

				char userTypeString = rs.getString(1).charAt(0);

				//System.out.println("User Type is " + userTypeString);
				
				switch (userTypeString) {

				case 'A':
					userType = 3;
					break;

				case 'S':
					userType = 1;
					break;

				case 'R':
					userType = 2;
					break;

				default:
					userType = 0;
					break;
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return userType;
	}

}
