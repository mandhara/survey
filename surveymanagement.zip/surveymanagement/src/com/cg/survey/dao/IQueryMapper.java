package com.cg.survey.dao;

public interface IQueryMapper {

	public static final String VALIDATE_USER_QUERY = "SELECT User_Type FROM User_Master WHERE User_ID = ? and User_Password = ?";

	public static final String INSERT_INTO_SURVEY_MASTER = "INSERT INTO Survey_Master values(survey_seq.NEXTVAL,?,?,?)";
	public static final String GET_SURVEY_SEQ_VALUE = "SELECT survey_seq.CURRVAL from dual";

    public static final String INSERT_INTO_SURVEY_QUESTIONS = "INSERT INTO Survey_Question_Details values(question_seq.NEXTVAL,?,?,?)";
	public static final String GET_QUES_SEQ_VALUE = "SELECT question_seq.CURRVAL from dual";
	
	public static final String INSERT_INTO_SURVEY_OPTIONS = "INSERT INTO Survey_Question_Options values(option_seq.NEXTVAL,?,?,?,?,?,?,?,?,?)";
	public static final String GET_OPT_SEQ_VALUE = "SELECT option_seq.CURRVAL from dual";
	
	public static final String EDIT_ADD_QUESTION = "INSERT INTO Survey_Question_Details values(question_seq1.NEXTVAL,?,?,?)";
	public static final String GET_QUES_SEQ_VALUE1 = "SELECT question_seq1.CURRVAL from dual";
	 
	public static final String VIEW_SURVEYS = "SELECT * FROM SURVEY_MASTER"; 
	
	public static final String INSERT_INTO_SURVEY_DISTRIBUTION= "INSERT INTO Survey_Distribution values(distributed_seq.NEXTVAL,?,?)";
	public static final String GET_DIST_SEQ_VALUE = "SELECT distributed_seq.CURRVAL from dual";
	
	public static final String VIEW_DISTRIBUTED_SURVEYS = "SELECT Survey_Distribution.Distribution_ID,Survey_Master.Survey_ID, Survey_Master.Survey_Title,Survey_Distribution.Distributed_Date FROM Survey_Distribution, Survey_Master where Survey_Master.Survey_ID=Survey_Distribution.Survey_ID";
	
	public static final String VIEW_DISTRIBUTED_SURVEYS1 = "SELECT sm.Survey_ID,sm.Survey_Title,sm.Survey_Description,sq.Question_ID,sq.Question_Text,so.Option_ID,so.Option_ID1,so.Option_Description1,so.Option_ID2,so.Option_Description2,so.Option_ID3,so.Option_Description3,so.Option_ID4,so.Option_Description4 FROM Survey_Master sm,Survey_Question_Details sq,Survey_Question_Options so where sm.Survey_ID = sq.Survey_ID and sq.Question_ID = so.Question_ID and sm.Survey_ID =?"; 
	public static final String VIEW_DISTRIBUTED_SURVEYS2 = "SELECT sm.Survey_ID,sm.Survey_Title,sm.Survey_Description,sq.Question_ID,sq.Question_Text,so.Option_ID,so.Option_ID1,so.Option_Description1,so.Option_ID2,so.Option_Description2,so.Option_ID3,so.Option_Description3,so.Option_ID4,so.Option_Description4 FROM Survey_Master sm,Survey_Question_Details sq,Survey_Question_Options so where sm.Survey_ID = sq.Survey_ID and sq.Question_ID = so.Question_ID"; 
	
	
	

}
