package com.cg.survey.client;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.survey.bean.DistributedSurveys;
import com.cg.survey.bean.DistributedSurveys1;
import com.cg.survey.bean.DistributedSurveys2;
import com.cg.survey.bean.SurveyDistribution;
import com.cg.survey.bean.SurveyMaster;
import com.cg.survey.bean.SurveyQuestionDetails;
import com.cg.survey.bean.SurveyQuestionOptions;
import com.cg.survey.bean.User;
import com.cg.survey.exception.SurveyProblemException;
import com.cg.survey.service.IMsgMapper;
import com.cg.survey.service.LoginService;
import com.cg.survey.service.LoginServiceImp;
import com.cg.survey.service.SurveyServiceI;
import com.cg.survey.service.SurveyServiceImplementation;

public class  Client {

	
	static LoginService Login = new LoginServiceImp();
	  SurveyQuestionDetails questionDetails = new SurveyQuestionDetails();
	  SurveyQuestionOptions optionDetails = new SurveyQuestionOptions();
	  SurveyMaster surveyDetails = new SurveyMaster();
	  SurveyMaster surveyDetails1 = new SurveyMaster();
		SurveyDistribution ds = new SurveyDistribution();
	
		
	  static SurveyServiceI surveyServiceImplementation = new SurveyServiceImplementation();
	static Scanner stringInputs;
	static Scanner scanner;


	public static void main(String[] args) throws SurveyProblemException {

		scanner = new Scanner(System.in);
		stringInputs = new Scanner(System.in);

		System.out.println("---------Survey Management System------------- ");
		System.out.println();

		System.out.println("Enter userId");
		int userId = scanner.nextInt();

		System.out.println("Enter password");
		String userPassword = scanner.next();

		// Creating User Object For Future use

		User loginUser = new User();
		loginUser.setUserId(userId);
		loginUser.setUserPassword(userPassword);

		// Creating Object Of Service Class Which has userLoginService() Method
		// It takes User object as a parameter

		LoginServiceImp loginServiceImp = new LoginServiceImp();
		int userType = loginServiceImp.userLoginService(loginUser);

		switch (userType) {

		case 0:
			printMessageForInvalidUser();
			break;

		case 1:
			loginAsSurveyor(userId);

			break;

		case 2:
			loginAsRespondent(userId);
			break;

		case 3:
			loginAsAdmin(userId);
			break;

		default:
			printMessageForInvalidUser();
			break;
		}

	}

	// 1. When User Login As Surveyor
	
	private static void loginAsSurveyor(int userID) throws SurveyProblemException {

		// TODO Auto-generated method stub

		System.out.println("Logged in successfully as Surveyor");

		System.out.println("1.Create Survey\n" + "2.For Edit Survey\n"
				+ "3.For Distribute Survey\n" + "4.For Viewing Results");

		int surveyInput = scanner.nextInt();

		switch (surveyInput) {
		
		case 1:
		       
			System.out.println("**Survey Details**\n");
					
			System.out.println("Enter Survey Title");
			String surveyTitle = stringInputs.nextLine();

			System.out.println("Enter Survey Description");
			String surveyDescription = stringInputs.nextLine();

			System.out.println("Question Details\n");
			
			System.out.println("Enter Survey Question Type");
			System.out.println("1.Question that have choice and more than one option");
			System.out.println("2.Question with descriptive answer");
			int questionType = scanner.nextInt();

			System.out.println("Enter Survey Question");
			String questionText = stringInputs.nextLine();
			
            System.out.println("Option Details\n");
			
            System.out.println("Enter first option Id");
			int optionID1 = scanner.nextInt();
			
			System.out.println("Enter first option ");
			String optionDescription1 = stringInputs.nextLine();
			
			 System.out.println("Enter second option Id");
			 int optionID2 = scanner.nextInt();
			 
			System.out.println("Enter second option ");
			String optionDescription2 = stringInputs.nextLine();
			
			  System.out.println("Enter third option Id");
				int optionID3 = scanner.nextInt();
				
			System.out.println("Enter third option ");
			String optionDescription3 = stringInputs.nextLine();
			
			  System.out.println("Enter fourth option Id");
				int optionID4 = scanner.nextInt();
				
			System.out.println("Enter fourth option ");
			String optionDescription4 = stringInputs.nextLine();
		
			SurveyMaster surveyDetails = new SurveyMaster();

			surveyDetails.setSurveyTitle(surveyTitle);
			surveyDetails.setSurveyDescription(surveyDescription);
			surveyDetails.setUserId(userID);
			 
			SurveyQuestionDetails questionDetails = new SurveyQuestionDetails();

			questionDetails.setQuestionType(questionType);
			questionDetails.setQuestionText(questionText);
		    questionDetails.setSurveyId(surveyDetails.getSurveyId());
		    
		    SurveyQuestionOptions optionDetails = new SurveyQuestionOptions();

			
			questionDetails.setQuestionId(questionDetails.getQuestionId());
			optionDetails.setOptionId1(optionID1);
			optionDetails.setOptionDescription1(optionDescription1);
			optionDetails.setOptionId2(optionID2);
			optionDetails.setOptionDescription2(optionDescription2);
			optionDetails.setOptionId3(optionID3);
			optionDetails.setOptionDescription3(optionDescription3);
			optionDetails.setOptionId4(optionID4);
			optionDetails.setOptionDescription4(optionDescription4);
		
			try {
				SurveyServiceImplementation surveyServiceImplementation = new SurveyServiceImplementation();
				int status = surveyServiceImplementation.createSurvey(surveyDetails);
				System.out.println("survey Id:\n"+ surveyDetails.getSurveyId());
			
		int status1 = surveyServiceImplementation.createQuestion(questionDetails,surveyDetails);
			System.out.println("Question Id:\n"+ questionDetails.getQuestionId());
		
			
		int status2 = surveyServiceImplementation.createOptions(optionDetails,questionDetails);
	System.out.println("Option Id:\n"+ optionDetails.getOptionId());
			
			if (status == 1 && status1 ==1 && status2 ==1) {
			System.out.println("SurveyDetails added successfully\n");
				}
		
			} catch (SurveyProblemException e) {
				System.err.println("exception: " + e.getMessage());
			}
			break;

		case 2:
			//editSurvey(userID, service);
		/*	System.out.println("**Edit Survey**\n");
			System.out.println("Enter the survey Id");
			int surveyId = scanner.nextInt();
              System.out.println("Question Details\n");
			
			System.out.println("Enter Survey Question Type");
			System.out.println("1.Question that have choice and more than one option");
			System.out.println("2.Question with descriptive answer");
			int questionType = scanner.nextInt();

			System.out.println("Enter Survey Question");
			String questionText = stringInputs.nextLine();
			
			
			 
		//SurveyQuestionDetails questionDetails = new SurveyQuestionDetails();

			questionDetails.setQuestionType(questionType);
			questionDetails.setQuestionText(questionText);
		    questionDetails.setSurveyId(surveyDetails.getSurveyId());*/
		    
			break;

		case 3:
			// distributeSurvey(userID, service);
			System.out.println("**Distribute Survey**\n");
			ArrayList<SurveyMaster> surveyList = new ArrayList<SurveyMaster>();
			surveyList = surveyServiceImplementation.viewSurveys();
			for(SurveyMaster surveyDetails1:surveyList)
			{
				System.out.println("Survey ID:" + surveyDetails1.getSurveyId());
				System.out.println("Survey Title:"  + surveyDetails1.getSurveyTitle());
				System.out.println("Survey description:" + surveyDetails1.getSurveyDescription());
				System.out.println("user ID:"  + surveyDetails1.getUserId());
				System.out.println("");
			}
			SurveyMaster surveyDetails1 = new SurveyMaster();
			
			System.out.println("Enter the survey ID\n");
			int surveyId = scanner.nextInt();
			
			
			System.out.println("Enter the distribution date\n");
			String distributedDate = scanner.next();
			
		
		
			SurveyDistribution DistributionDetails = new SurveyDistribution();
			
			DistributionDetails.setSurveyId(surveyDetails1.getSurveyId());
			DistributionDetails.setDistributedDate(distributedDate);
			
			try {
				SurveyServiceImplementation surveyServiceImplementation = new SurveyServiceImplementation();
				int status = surveyServiceImplementation.distributeSurvey(DistributionDetails, surveyDetails1);
				System.out.println("survey distributed:\n");
				if (status == 1) {
					System.out.println("SurveyDetails added successfully\n");
						}
				
					} catch (SurveyProblemException e) {
						System.err.println("exception: " + e.getMessage());
					}
					break;

	

		case 4:
			// reviewResultsOfSurvey(userID, service);
			break;

		default:
			break;
		}
		}

	

	private static void loginAsAdmin(int userID) throws SurveyProblemException {
		// TODO Auto-generated method stub

		System.out.println("Logged in successfully As Admin ");
		

		System.out.println("1.Create Survey\n" + "2.For Edit Survey\n"
				+ "3.For Distribute Survey\n" + "4.For Viewing Results\n" + "5.Respond Survey\n" + "6.view responded survey details\n");

		int surveyInput = scanner.nextInt();

		switch (surveyInput) {
		
		case 1:
		       
			System.out.println("**Survey Details**\n");
					
			System.out.println("Enter Survey Title");
			String surveyTitle = stringInputs.nextLine();

			System.out.println("Enter Survey Description");
			String surveyDescription = stringInputs.nextLine();

			System.out.println("Question Details\n");
			
			System.out.println("Enter Survey Question Type");
			System.out.println("1.Question that have choice and more than one option");
			System.out.println("2.Question with descriptive answer");
			int questionType = scanner.nextInt();

			System.out.println("Enter Survey Question");
			String questionText = stringInputs.nextLine();
			
            System.out.println("Option Details\n");
			
            System.out.println("Enter first option Id");
			int optionID1 = scanner.nextInt();
			
			System.out.println("Enter first option ");
			String optionDescription1 = stringInputs.nextLine();
			
			 System.out.println("Enter second option Id");
			 int optionID2 = scanner.nextInt();
			 
			System.out.println("Enter second option ");
			String optionDescription2 = stringInputs.nextLine();
			
			  System.out.println("Enter third option Id");
				int optionID3 = scanner.nextInt();
				
			System.out.println("Enter third option ");
			String optionDescription3 = stringInputs.nextLine();
			
			  System.out.println("Enter fourth option Id");
				int optionID4 = scanner.nextInt();
				
			System.out.println("Enter fourth option ");
			String optionDescription4 = stringInputs.nextLine();
		
			SurveyMaster surveyDetails = new SurveyMaster();

			surveyDetails.setSurveyTitle(surveyTitle);
			surveyDetails.setSurveyDescription(surveyDescription);
			surveyDetails.setUserId(userID);
			 
			SurveyQuestionDetails questionDetails = new SurveyQuestionDetails();

			questionDetails.setQuestionType(questionType);
			questionDetails.setQuestionText(questionText);
		    questionDetails.setSurveyId(surveyDetails.getSurveyId());
		    
		    SurveyQuestionOptions optionDetails = new SurveyQuestionOptions();

			
			questionDetails.setQuestionId(questionDetails.getQuestionId());
			optionDetails.setOptionId1(optionID1);
			optionDetails.setOptionDescription1(optionDescription1);
			optionDetails.setOptionId2(optionID2);
			optionDetails.setOptionDescription2(optionDescription2);
			optionDetails.setOptionId3(optionID3);
			optionDetails.setOptionDescription3(optionDescription3);
			optionDetails.setOptionId4(optionID4);
			optionDetails.setOptionDescription4(optionDescription4);
		
			try {
				SurveyServiceImplementation surveyServiceImplementation = new SurveyServiceImplementation();
				int status = surveyServiceImplementation.createSurvey(surveyDetails);
				System.out.println("survey Id:\n"+ surveyDetails.getSurveyId());
			
		int status1 = surveyServiceImplementation.createQuestion(questionDetails,surveyDetails);
			System.out.println("Question Id:\n"+ questionDetails.getQuestionId());
		
			
		int status2 = surveyServiceImplementation.createOptions(optionDetails,questionDetails);
	System.out.println("Option Id:\n"+ optionDetails.getOptionId());
			
			if (status == 1 && status1 ==1 && status2 ==1) {
			System.out.println("SurveyDetails added successfully\n");
				}
		
			} catch (SurveyProblemException e) {
				System.err.println("exception: " + e.getMessage());
			}
			break;

		case 2:
			//editSurvey(userID, service);
		/*	System.out.println("**Edit Survey**\n");
			System.out.println("Enter the survey Id");
			int surveyId = scanner.nextInt();
              System.out.println("Question Details\n");
			
			System.out.println("Enter Survey Question Type");
			System.out.println("1.Question that have choice and more than one option");
			System.out.println("2.Question with descriptive answer");
			int questionType = scanner.nextInt();

			System.out.println("Enter Survey Question");
			String questionText = stringInputs.nextLine();
			
			
			 
		//SurveyQuestionDetails questionDetails = new SurveyQuestionDetails();

			questionDetails.setQuestionType(questionType);
			questionDetails.setQuestionText(questionText);
		    questionDetails.setSurveyId(surveyDetails.getSurveyId());*/
		    
			break;

		case 3:
			// distributeSurvey(userID, service);
			System.out.println("**Distribute Survey**\n");
			ArrayList<SurveyMaster> surveyList = new ArrayList<SurveyMaster>();
			surveyList = surveyServiceImplementation.viewSurveys();
			for(SurveyMaster surveyDetails1:surveyList)
			{
				System.out.println("Survey ID:" + surveyDetails1.getSurveyId());
				System.out.println("Survey Title:"  + surveyDetails1.getSurveyTitle());
				System.out.println("Survey description:" + surveyDetails1.getSurveyDescription());
				System.out.println("user ID:"  + surveyDetails1.getUserId());
				System.out.println("");
			}
			SurveyMaster surveyDetails1 = new SurveyMaster();
			
			System.out.println("Enter the survey ID\n");
			int surveyId = scanner.nextInt();
			
			
			System.out.println("Enter the distriution date\n");
			String distributedDate = scanner.next();
			
		
		
			SurveyDistribution DistributionDetails = new SurveyDistribution();
			
			DistributionDetails.setSurveyId(surveyDetails1.getSurveyId());
			DistributionDetails.setDistributedDate(distributedDate);
			
			try {
				SurveyServiceImplementation surveyServiceImplementation = new SurveyServiceImplementation();
				int status = surveyServiceImplementation.distributeSurvey(DistributionDetails, surveyDetails1);
				System.out.println("survey distributed:\n");
				if (status == 1) {
					System.out.println("SurveyDetails added successfully\n");
						}
				
					} catch (SurveyProblemException e) {
						System.err.println("exception: " + e.getMessage());
					}
					break;

	

		case 4:
			// reviewResultsOfSurvey(userID, service);
			break;
		case 5:
			
				System.out.println("Available surveys:\n");
				ArrayList<DistributedSurveys> DistributedSurveyList = new ArrayList<DistributedSurveys>();
				DistributedSurveyList = surveyServiceImplementation.RespondSurveys();
				for(DistributedSurveys ds:DistributedSurveyList)
				{
					System.out.println("Survey ID:" + ds.getSurveyId());
					System.out.println("Distribution ID:"  + ds.getDistributionId());
					System.out.println("Survey Title:" + ds.getSurveyTitle());
					System.out.println("Distribution date:"  + ds.getDistributedDate());
					System.out.println("");
				}
					System.out.println("Enter the Survey Id\n");
				
					int surveyId1 = scanner.nextInt();
					
					ArrayList<DistributedSurveys1> DistributedSurveyList1 = new ArrayList<DistributedSurveys1>();
					DistributedSurveyList1 = surveyServiceImplementation.RespondSurveys1(surveyId1);
					for(DistributedSurveys1 ds1:DistributedSurveyList1)
					{
				        System.out.println("************************************");
						System.out.println("*"+ds1.getSurveyTitle()+"*");
						 System.out.println("************************************");
						System.out.println(ds1.getSurveyDescription());
						System.out.println("");
						System.out.println(ds1.getQuestionId()+".  "+ds1.getQuestionText());
						System.out.println("");
						System.out.println(ds1.getOptionId1()+".  "+ds1.getOptionDescription1());
						System.out.println(ds1.getOptionId2()+".  "+ds1.getOptionDescription2());
						System.out.println(ds1.getOptionId3()+".  "+ds1.getOptionDescription3());
						System.out.println(ds1.getOptionId4()+".  "+ds1.getOptionDescription4());
						System.out.println("");
						System.out.println("select option: ");
						int optionId= scanner.nextInt();
						 
					}
					System.out.println("Response stored successfully");
					
					
				
				break;
				
			
			
		default:
			break;
		}
		}
		
			
	

	private static void loginAsRespondent(int userID) throws SurveyProblemException {
		// TODO Auto-generated method stub
		System.out.println("Logged In successfully As Respondent ");
		System.out.println("1.Respond Survey\n" + "2.view responded survey details\n");

		int surveyInput1 = scanner.nextInt();
	
		switch (surveyInput1) {
		
		case 1:
			System.out.println("Available surveys:\n");
			ArrayList<DistributedSurveys> DistributedSurveyList = new ArrayList<DistributedSurveys>();
			DistributedSurveyList = surveyServiceImplementation.RespondSurveys();
			for(DistributedSurveys ds:DistributedSurveyList)
			{
				System.out.println("Survey ID:" + ds.getSurveyId());
				System.out.println("Distribution ID:"  + ds.getDistributionId());
				System.out.println("Survey Title:" + ds.getSurveyTitle());
				System.out.println("Distribution date:"  + ds.getDistributedDate());
				System.out.println("");
			}
				System.out.println("Enter the Survey Id\n");
			
				int surveyId = scanner.nextInt();
				
				ArrayList<DistributedSurveys1> DistributedSurveyList1 = new ArrayList<DistributedSurveys1>();
				DistributedSurveyList1 = surveyServiceImplementation.RespondSurveys1(surveyId);
				for(DistributedSurveys1 ds1:DistributedSurveyList1)
				{
			        System.out.println("************************************");
					System.out.println("*"+ds1.getSurveyTitle()+"*");
					 System.out.println("************************************");
					System.out.println(ds1.getSurveyDescription());
					System.out.println("");
					System.out.println(ds1.getQuestionId()+".  "+ds1.getQuestionText());
					System.out.println("");
					System.out.println(ds1.getOptionId1()+".  "+ds1.getOptionDescription1());
					System.out.println(ds1.getOptionId2()+".  "+ds1.getOptionDescription2());
					System.out.println(ds1.getOptionId3()+".  "+ds1.getOptionDescription3());
					System.out.println(ds1.getOptionId4()+".  "+ds1.getOptionDescription4());
					System.out.println("");
					System.out.println("select option: ");
					int optionId= scanner.nextInt();
					 
				}
				System.out.println("Response stored successfully");
				
			
			break;
			
		case 2:
		

		default:
			break;
		}
			
	}	
			
		

	

	private static void printMessageForInvalidUser() {
		// TODO Auto-generated method stub
		System.out.println("Invalid User Login");
	}

}
