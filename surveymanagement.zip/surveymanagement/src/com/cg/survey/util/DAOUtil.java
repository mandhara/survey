package com.cg.survey.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAOUtil {

	static Connection conn=null;
	
	public static Connection establishConnection() throws SQLException {

		conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg227","training227");
	return conn;
	}
}


